import { useCallback, useEffect, useMemo, useState } from 'react';

const API = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/$/, '');
const GENRES = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller'];
const PLATFORMS = ['Netflix', 'Prime Video', 'Hotstar', 'Theatre', 'Other'];
const STATUSES = ['To Watch', 'Watching', 'Watched'];
const emptyForm = { title: '', genre: 'Drama', releaseYear: String(new Date().getFullYear()), runtime: '120', platform: 'Netflix', priority: '3' };

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const payload = await response.json().catch(() => ({ success: false, message: 'The server returned an unreadable response' }));
  if (!response.ok || !payload.success) throw new Error(payload.message || 'Request failed');
  return payload.data;
}

function Field({ label, children }) {
  return <label className="field"><span>{label}</span>{children}</label>;
}

export default function App() {
  const [movies, setMovies] = useState([]);
  const [stats, setStats] = useState(null);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [genreFilter, setGenreFilter] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [watchNext, setWatchNext] = useState(null);
  const [ratingFor, setRatingFor] = useState({});
  const [ratingEdit, setRatingEdit] = useState({});
  const [showForm, setShowForm] = useState(false);

  const loadStats = useCallback(async () => {
    try { setStats(await api('/stats')); } catch (e) { setError(e.message); }
  }, []);

  const loadMovies = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page) });
      if (search.trim()) params.set('search', search.trim());
      if (statusFilter) params.set('status', statusFilter);
      if (genreFilter) params.set('genre', genreFilter);
      const data = await api(`/movies?${params}`);
      setMovies(data.movies);
      setPages(Math.max(1, data.totalPages));
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [page, search, statusFilter, genreFilter]);

  useEffect(() => { loadMovies(); }, [loadMovies]);
  useEffect(() => { loadStats(); }, [loadStats]);

  const resetForm = () => { setForm(emptyForm); setEditing(null); setShowForm(false); };
  const refresh = async () => { await Promise.all([loadMovies(), loadStats()]); };

  function startEdit(movie) {
    setEditing(movie);
    setForm({ title: movie.title, genre: movie.genre, releaseYear: String(movie.releaseYear), runtime: String(movie.runtime), platform: movie.platform, priority: String(movie.priority) });
    setShowForm(true);
    setError('');
    setNotice('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function submitMovie(event) {
    event.preventDefault();
    setError(''); setNotice('');
    const year = Number(form.releaseYear), runtime = Number(form.runtime), priority = Number(form.priority);
    if (!form.title.trim()) return setError('Please enter a title.');
    if (!editing && (!Number.isInteger(year) || year < 1950 || year > new Date().getFullYear())) return setError(`Release year must be from 1950 to ${new Date().getFullYear()}.`);
    if (!Number.isInteger(runtime) || runtime < 30 || runtime > 300) return setError('Runtime must be from 30 to 300 minutes.');
    if (!Number.isInteger(priority) || priority < 1 || priority > 5) return setError('Priority must be from 1 to 5.');
    const body = { title: form.title.trim(), genre: form.genre, runtime, platform: form.platform, priority };
    if (!editing) body.releaseYear = year;
    try {
      if (editing) await api(`/movies/${editing._id}`, { method: 'PUT', body: JSON.stringify(body) });
      else await api('/movies', { method: 'POST', body: JSON.stringify(body) });
      setNotice(editing ? 'Movie updated.' : 'Movie added to your watchlist.');
      resetForm(); setPage(1); await refresh();
    } catch (e) { setError(e.message); }
  }

  async function changeStatus(movie, nextStatus) {
    setError(''); setNotice('');
    let rating;
    if (nextStatus === 'Watched') {
      rating = Number(ratingFor[movie._id]);
      if (!Number.isInteger(rating) || rating < 1 || rating > 10) return setError(`Choose a rating from 1 to 10 for “${movie.title}” first.`);
    }
    try {
      await api(`/movies/${movie._id}/status`, { method: 'PATCH', body: JSON.stringify({ status: nextStatus, ...(nextStatus === 'Watched' ? { rating } : {}) }) });
      setNotice(`${movie.title} moved to ${nextStatus}.`);
      setRatingFor(old => ({ ...old, [movie._id]: '' }));
      await refresh();
    } catch (e) { setError(e.message); }
  }

  async function saveRating(movie) {
    const rating = Number(ratingEdit[movie._id]);
    if (!Number.isInteger(rating) || rating < 1 || rating > 10) return setError('Rating must be from 1 to 10.');
    try {
      await api(`/movies/${movie._id}/rating`, { method: 'PATCH', body: JSON.stringify({ rating }) });
      setNotice('Rating updated.');
      setRatingEdit(old => ({ ...old, [movie._id]: '' }));
      await refresh();
    } catch (e) { setError(e.message); }
  }

  async function deleteMovie(movie) {
    if (movie.status === 'Watching') return;
    if (!window.confirm(`Delete “${movie.title}”? This cannot be undone.`)) return;
    try {
      await api(`/movies/${movie._id}`, { method: 'DELETE' });
      setNotice('Movie deleted.');
      await refresh();
    } catch (e) { setError(e.message); }
  }

  async function findNext() {
    setError(''); setWatchNext(null);
    try { setWatchNext(await api('/movies/watch-next')); }
    catch (e) { setError(e.message); }
  }

  const statusCounts = stats?.statusCounts || { 'To Watch': 0, Watching: 0, Watched: 0 };
  const statsCards = useMemo(() => [
    { label: 'In your list', value: stats?.totalMovies ?? '—', note: 'All movies' },
    { label: 'To watch', value: statusCounts['To Watch'], note: 'Ready for a movie night' },
    { label: 'Hours watched', value: stats?.totalHoursWatched ?? 0, note: 'From watched runtimes' },
    { label: 'Average rating', value: stats?.averageRating ?? '—', note: 'Out of 10' }
  ], [stats, statusCounts]);

  return <main className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={e => { e.preventDefault(); setPage(1); setSearch(''); setStatusFilter(''); setGenreFilter(''); }}>
        <span className="brand-mark">R</span><span>Reel<span className="accent">List</span><small>YOUR PERSONAL CINEMA</small></span>
      </a>
      <div className="topbar-right"><span className="live-dot" /> YOUR MOVIE SPACE <button className="primary small" onClick={() => { setEditing(null); setForm(emptyForm); setShowForm(v => !v); }}>＋ Add movie</button></div>
    </header>

    <section className="hero">
      <div className="hero-copy">
        <div className="eyebrow"><span /> YOUR NEXT GREAT WATCH STARTS HERE</div>
        <h1>Make movie night<br /><em>count.</em></h1>
        <p>A little less scrolling. A lot more watching. Keep your favorites, plans and ratings all in one place.</p>
        <button className="primary hero-button" onClick={findNext}>▶ What should I watch next?</button>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="poster poster-back"><span>STORIES<br />AFTER<br />DARK</span></div>
        <div className="poster poster-mid"><span>THE<br />LAST<br />FRAME</span></div>
        <div className="poster poster-front"><div className="poster-sun" /><span>ONE MORE<br />SCENE</span><small>A FILM BY YOU</small></div>
        <div className="hero-orbit" />
      </div>
    </section>

    {error && <div className="alert error-alert" role="alert"><span>!</span>{error}<button onClick={() => setError('')} aria-label="Dismiss">×</button></div>}
    {notice && <div className="alert success-alert" role="status"><span>✓</span>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}

    {watchNext && <section className="recommendation"><div><span className="eyebrow">TONIGHT'S PICK</span><h2>{watchNext.title}</h2><p>{watchNext.genre} · {watchNext.runtime} min · Priority {watchNext.priority}/5</p><small>{watchNext.movieCode}</small></div><button className="ghost" onClick={() => setWatchNext(null)}>Dismiss</button></section>}

    <section className="stats-grid">
      {statsCards.map((item, i) => <article className="stat-card" key={item.label}><div className={`stat-icon icon-${i}`}>{['▣','◷','◴','★'][i]}</div><div><p>{item.label}</p><strong>{item.value}</strong><small>{item.note}</small></div></article>)}
    </section>
    <section className="insight-row"><div><span className="eyebrow">YOUR TASTE, AT A GLANCE</span><h2>Keep your story rolling.</h2></div><div className="genre-insight"><span className="genre-symbol">✦</span><div><small>MOST WATCHED GENRE</small><strong>{stats?.mostWatchedGenre || 'Not enough data yet'}</strong></div></div></section>

    {showForm && <section className="form-panel" id="movie-form">
      <div className="section-heading"><div><span className="eyebrow">{editing ? 'UPDATE YOUR COLLECTION' : 'ADD TO YOUR COLLECTION'}</span><h2>{editing ? 'Edit movie' : 'A new story awaits.'}</h2></div><button className="icon-button" onClick={resetForm} aria-label="Close form">×</button></div>
      <form className="movie-form" onSubmit={submitMovie}>
        <Field label="Movie title"><input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} maxLength="120" placeholder="e.g. Interstellar" required /></Field>
        <Field label="Genre"><select value={form.genre} onChange={e => setForm({ ...form, genre: e.target.value })}>{GENRES.map(x => <option key={x}>{x}</option>)}</select></Field>
        <Field label="Release year"><input type="number" min="1950" max={new Date().getFullYear()} value={form.releaseYear} disabled={!!editing} onChange={e => setForm({ ...form, releaseYear: e.target.value })} required /></Field>
        <Field label="Runtime (minutes)"><input type="number" min="30" max="300" value={form.runtime} onChange={e => setForm({ ...form, runtime: e.target.value })} required /></Field>
        <Field label="Streaming platform"><select value={form.platform} onChange={e => setForm({ ...form, platform: e.target.value })}>{PLATFORMS.map(x => <option key={x}>{x}</option>)}</select></Field>
        <Field label="Priority"><select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>{[5,4,3,2,1].map(x => <option value={x} key={x}>{x} — {x === 5 ? 'Must watch' : x === 1 ? 'Someday' : 'Priority'}</option>)}</select></Field>
        <div className="form-actions"><button type="button" className="ghost" onClick={resetForm}>Cancel</button><button className="primary" type="submit">{editing ? 'Save changes' : 'Add to watchlist'}</button></div>
      </form>
    </section>}

    <section className="collection-section">
      <div className="section-heading collection-heading"><div><span className="eyebrow">THE COLLECTION</span><h2>Your watchlist <span className="count">{stats?.totalMovies ?? 0}</span></h2></div><span className="collection-caption">EVERY FILM HAS ITS MOMENT</span></div>
      <div className="toolbar">
        <label className="search-box"><span>⌕</span><input placeholder="Search your movies..." value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} /></label>
        <select aria-label="Filter by status" value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}><option value="">All statuses</option>{STATUSES.map(x => <option key={x}>{x}</option>)}</select>
        <select aria-label="Filter by genre" value={genreFilter} onChange={e => { setGenreFilter(e.target.value); setPage(1); }}><option value="">All genres</option>{GENRES.map(x => <option key={x}>{x}</option>)}</select>
      </div>
      {loading ? <div className="empty-state">Loading your collection…</div> : movies.length === 0 ? <div className="empty-state"><span>✧</span><h3>Your next favorite is waiting.</h3><p>No movies match these filters yet. Add a film to start your collection.</p><button className="primary" onClick={() => setShowForm(true)}>＋ Add your first movie</button></div> :
        <div className="movie-grid">{movies.map(movie => <article className="movie-card" key={movie._id}>
          <div className={`card-art art-${GENRES.indexOf(movie.genre) % 7}`}><span className="art-code">{movie.movieCode}</span><div className="art-symbol">{['✦','☼','◈','☾','⌁','♡','✧'][GENRES.indexOf(movie.genre)]}</div><span className="art-genre">{movie.genre.toUpperCase()}</span><span className={`status-badge status-${movie.status.toLowerCase().replace(' ', '-')}`}>{movie.status}</span></div>
          <div className="movie-info"><div className="movie-title-row"><h3>{movie.title}</h3><span className="priority">P{movie.priority}</span></div><p className="movie-meta">{movie.releaseYear} <span>·</span> {movie.runtime} min <span>·</span> {movie.platform}</p>
            {movie.status === 'Watched' ? <div className="rating-line"><span className="star">★</span> {movie.rating}/10 <small>{movie.watchedDate ? `· Watched ${new Date(movie.watchedDate).toLocaleDateString()}` : ''}</small></div> : <div className="card-controls">
              <select aria-label={`Change status for ${movie.title}`} value="" onChange={e => { if (e.target.value) changeStatus(movie, e.target.value); }}>
                <option value="">Move to…</option>{(movie.status === 'To Watch' ? ['Watching', 'Watched'] : ['To Watch', 'Watched']).map(x => <option key={x}>{x}</option>)}
              </select>
              {movie.status === 'To Watch' && <select aria-label={`Rating for ${movie.title}`} value={ratingFor[movie._id] || ''} onChange={e => setRatingFor(old => ({ ...old, [movie._id]: e.target.value }))}><option value="">Rating…</option>{Array.from({ length: 10 }, (_, i) => i + 1).map(n => <option key={n} value={n}>{n}/10</option>)}</select>}
            </div>}
            {movie.status === 'Watched' && <div className="rating-edit"><select aria-label={`New rating for ${movie.title}`} value={ratingEdit[movie._id] || ''} onChange={e => setRatingEdit(old => ({ ...old, [movie._id]: e.target.value }))}><option value="">Edit rating…</option>{Array.from({ length: 10 }, (_, i) => i + 1).map(n => <option key={n} value={n}>{n}/10</option>)}</select><button className="text-button" onClick={() => saveRating(movie)}>Save</button></div>}
            <div className="card-footer"><button className="text-button" onClick={() => startEdit(movie)}>Edit details</button><button className="text-button danger-text" disabled={movie.status === 'Watching'} title={movie.status === 'Watching' ? 'Watching movies cannot be deleted' : 'Delete movie'} onClick={() => deleteMovie(movie)}>Delete</button></div>
          </div>
        </article>)}</div>}
      <div className="pagination"><span>Page {page} of {pages}</span><div><button className="ghost" disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>← Previous</button><button className="ghost" disabled={page >= pages} onClick={() => setPage(p => Math.min(pages, p + 1))}>Next →</button></div></div>
    </section>
    <footer><a className="brand footer-brand" href="#"><span className="brand-mark">R</span><span>Reel<span className="accent">List</span></span></a><span>Made for the love of a good story.</span><span>YOUR NEXT CHAPTER STARTS HERE ✦</span></footer>
  </main>;
}

# Movie Watchlist Manager (MERN)

A project-specific Movie Watchlist Manager for the MERN full-stack assessment.

## Features
- Add, list, edit, update status, rate watched movies, and delete permitted movies.
- Per-release-year movie codes (`MV-<year>-<sequence>`).
- Duplicate title/year detection (case-insensitive).
- Status transition and rating rules enforced by the backend.
- Backend search, genre/status filters, six-item pagination and priority ordering.
- Watch-next endpoint and statistics endpoint.
- Responsive React interface.

## Prerequisites
- Node.js 18+
- MongoDB Atlas test database (or local MongoDB)

## Setup
1. Create `backend/.env` from `backend/.env.example` and set `MONGODB_URI` to a test database URI.
2. In a terminal:
   ```bash
   cd backend
   npm install
   npm run dev
   ```
3. In a second terminal:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
4. Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

The frontend expects the backend at `http://localhost:5000/api`. Set `VITE_API_URL` in `frontend/.env` if needed.

## API endpoints
All responses use `{ "success": boolean, "message": string, "data": any }`.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/movies` | List/search/filter/paginate movies |
| GET | `/api/movies/:id` | Get one movie |
| POST | `/api/movies` | Create movie |
| PUT | `/api/movies/:id` | Edit allowed movie fields |
| PATCH | `/api/movies/:id/status` | Change status and optionally set rating |
| PATCH | `/api/movies/:id/rating` | Edit rating for a Watched movie |
| DELETE | `/api/movies/:id` | Delete unless status is Watching |
| GET | `/api/movies/watch-next` | Highest-priority To Watch movie (runtime tiebreaker) |
| GET | `/api/stats` | Dashboard statistics |
| GET | `/api/health` | Health check |

List query parameters: `page`, `status`, `genre`, `search`. Page size is fixed at six.

## Assessment notes
- `backend/.env.example` is safe to commit. Do not commit a real Atlas username/password or production secret. The exam sheet requests an `.env` file, but a public repository must not contain real credentials. Use only dummy/test credentials if an `.env` must be committed for evaluation, and rotate any exposed credentials.
- Movie-code allocation uses a MongoDB counter document per release year.
- Run your own tests and replace the screenshots section below with two screenshots of your running app before submission.

## Screenshots
Add two screenshots of the working application here before submitting, for example:
- `screenshots/dashboard.png`
- `screenshots/add-movie.png`

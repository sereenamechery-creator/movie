import mongoose from 'mongoose';

export const GENRES = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Romance', 'Thriller'];
export const PLATFORMS = ['Netflix', 'Prime Video', 'Hotstar', 'Theatre', 'Other'];
export const STATUSES = ['To Watch', 'Watching', 'Watched'];

const movieSchema = new mongoose.Schema({
  movieCode: { type: String, required: true, unique: true, immutable: true },
  title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 120 },
  titleKey: { type: String, required: true, select: false },
  genre: { type: String, enum: GENRES, required: true },
  releaseYear: { type: Number, required: true, min: 1950, max: new Date().getFullYear(), immutable: true },
  runtime: { type: Number, required: true, min: 30, max: 300 },
  platform: { type: String, enum: PLATFORMS, required: true },
  priority: { type: Number, required: true, min: 1, max: 5, validate: Number.isInteger },
  status: { type: String, enum: STATUSES, default: 'To Watch', required: true },
  rating: { type: Number, min: 1, max: 10, default: null },
  watchedDate: { type: Date, default: null }
}, { timestamps: true });

movieSchema.index({ titleKey: 1, releaseYear: 1 }, { unique: true });
movieSchema.index({ status: 1, priority: -1, runtime: 1 });
movieSchema.pre('validate', function(next) {
  if (this.title) this.titleKey = this.title.trim().toLocaleLowerCase('en');
  if (this.status === 'Watched' && (this.rating == null || this.rating < 1 || this.rating > 10)) {
    this.invalidate('rating', 'A rating from 1 to 10 is required for a Watched movie');
  }
  if (this.status !== 'Watched' && this.rating != null) {
    this.invalidate('rating', 'Rating is only allowed for Watched movies');
  }
  if (this.status !== 'Watched' && this.watchedDate != null) {
    this.invalidate('watchedDate', 'Watched Date is only allowed for Watched movies');
  }
  next();
});

export const Movie = mongoose.model('Movie', movieSchema);

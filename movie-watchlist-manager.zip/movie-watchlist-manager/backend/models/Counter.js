import mongoose from 'mongoose';

const counterSchema = new mongoose.Schema({
  _id: { type: Number, required: true },
  sequence: { type: Number, default: 0 }
}, { versionKey: false });

export const Counter = mongoose.model('Counter', counterSchema);

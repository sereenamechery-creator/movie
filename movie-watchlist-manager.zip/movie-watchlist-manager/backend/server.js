import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import movieRoutes from './routes/movies.js';
import { Movie } from './models/Movie.js';
import { sendError } from './utils/response.js';

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ success: true, message: 'API is running', data: { database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' } }));
app.use('/api/movies', movieRoutes);
app.get('/api/stats', async (_req, res, next) => {
  try {
    const [statusCounts, watchedSummary, genreRows] = await Promise.all([
      Movie.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
      Movie.aggregate([{ $match: { status: 'Watched' } }, { $group: { _id: null, count: { $sum: 1 }, runtime: { $sum: '$runtime' }, averageRating: { $avg: '$rating' } } }]),
      Movie.aggregate([{ $match: { status: 'Watched' } }, { $group: { _id: '$genre', count: { $sum: 1 } } }, { $sort: { count: -1, _id: 1 } }, { $limit: 1 }])
    ]);
    const counts = { 'To Watch': 0, Watching: 0, Watched: 0 };
    statusCounts.forEach(row => { counts[row._id] = row.count; });
    const summary = watchedSummary[0] || { count: 0, runtime: 0, averageRating: null };
    res.json({ success: true, message: 'Statistics loaded', data: {
      statusCounts: counts,
      totalMovies: Object.values(counts).reduce((a,b) => a+b, 0),
      totalHoursWatched: Math.round((summary.runtime / 60) * 10) / 10,
      averageRating: summary.averageRating == null ? null : Math.round(summary.averageRating * 10) / 10,
      mostWatchedGenre: genreRows[0]?._id || null,
      watchedMovies: summary.count
    }});
  } catch (error) { next(error); }
});
app.use((req, res) => sendError(res, 404, `Route not found: ${req.method} ${req.path}`));
app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.name === 'ValidationError') return sendError(res, 400, Object.values(error.errors).map(e => e.message).join(', '));
  if (error.name === 'CastError') return sendError(res, 400, 'Invalid movie ID');
  return sendError(res, 500, 'Unexpected server error');
});

const port = Number(process.env.PORT || 5000);
if (!process.env.MONGODB_URI) {
  console.error('Missing MONGODB_URI. Copy .env.example to .env and configure a test MongoDB URI.');
  process.exit(1);
}
mongoose.connect(process.env.MONGODB_URI)
  .then(() => app.listen(port, () => console.log(`Movie Watchlist API listening on http://localhost:${port}`)))
  .catch(error => { console.error('MongoDB connection failed:', error.message); process.exit(1); });

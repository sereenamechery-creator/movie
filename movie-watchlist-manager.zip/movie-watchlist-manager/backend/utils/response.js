export function sendError(res, status, message, data = null) {
  return res.status(status).json({ success: false, message, data });
}
export function sendSuccess(res, status, message, data) {
  return res.status(status).json({ success: true, message, data });
}

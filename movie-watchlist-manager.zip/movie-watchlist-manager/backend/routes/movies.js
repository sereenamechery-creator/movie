import { Router } from 'express';
import mongoose from 'mongoose';
import { Movie, GENRES, PLATFORMS, STATUSES } from '../models/Movie.js';
import { Counter } from '../models/Counter.js';
import { sendError, sendSuccess } from '../utils/response.js';

const router = Router();
const currentYear = () => new Date().getFullYear();
const allowedTransitions = {
  'To Watch': ['Watching', 'Watched'],
  Watching: ['Watched', 'To Watch'],
  Watched: []
};
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function validateMovieInput(body, { creating = false } = {}) {
  const errors = [];
  if (creating && (typeof body.title !== 'string' || !body.title.trim())) errors.push('Title is required');
  if (creating && !GENRES.includes(body.genre)) errors.push(`Genre must be one of: ${GENRES.join(', ')}`);
  if (creating && !PLATFORMS.includes(body.platform)) errors.push(`Platform must be one of: ${PLATFORMS.join(', ')}`);
  if (creating && (!Number.isInteger(Number(body.releaseYear)) || Number(body.releaseYear) < 1950 || Number(body.releaseYear) > currentYear())) errors.push(`Release Year must be between 1950 and ${currentYear()}`);
  if (creating && (!Number.isInteger(Number(body.runtime)) || Number(body.runtime) < 30 || Number(body.runtime) > 300)) errors.push('Runtime must be an integer from 30 to 300 minutes');
  if (creating && (!Number.isInteger(Number(body.priority)) || Number(body.priority) < 1 || Number(body.priority) > 5)) errors.push('Priority must be an integer from 1 to 5');
  if (!creating) {
    if (body.title !== undefined && (typeof body.title !== 'string' || !body.title.trim())) errors.push('Title cannot be empty');
    if (body.genre !== undefined && !GENRES.includes(body.genre)) errors.push('Invalid genre');
    if (body.platform !== undefined && !PLATFORMS.includes(body.platform)) errors.push('Invalid platform');
    if (body.runtime !== undefined && (!Number.isInteger(Number(body.runtime)) || Number(body.runtime) < 30 || Number(body.runtime) > 300)) errors.push('Runtime must be an integer from 30 to 300 minutes');
    if (body.priority !== undefined && (!Number.isInteger(Number(body.priority)) || Number(body.priority) < 1 || Number(body.priority) > 5)) errors.push('Priority must be an integer from 1 to 5');
  }
  return errors;
}
function editableFields(body) {
  const out = {};
  for (const key of ['title', 'genre', 'runtime', 'platform', 'priority']) {
    if (body[key] !== undefined) out[key] = key === 'runtime' || key === 'priority' ? Number(body[key]) : body[key];
  }
  return out;
}
function safeId(id) { return mongoose.isValidObjectId(id); }

router.get('/watch-next', asyncRoute(async (_req, res) => {
  const movie = await Movie.findOne({ status: 'To Watch' }).sort({ priority: -1, runtime: 1, createdAt: 1 });
  if (!movie) return sendError(res, 404, 'There are no movies in To Watch status');
  return sendSuccess(res, 200, 'Your next movie recommendation', movie);
}));

router.get('/', asyncRoute(async (req, res) => {
  const page = Math.max(1, Number.parseInt(req.query.page, 10) || 1);
  const filter = {};
  if (req.query.status) {
    if (!STATUSES.includes(req.query.status)) return sendError(res, 400, 'Invalid status filter');
    filter.status = req.query.status;
  }
  if (req.query.genre) {
    if (!GENRES.includes(req.query.genre)) return sendError(res, 400, 'Invalid genre filter');
    filter.genre = req.query.genre;
  }
  if (typeof req.query.search === 'string' && req.query.search.trim()) {
    filter.title = { $regex: req.query.search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
  }
  const totalItems = await Movie.countDocuments(filter);
  const totalPages = Math.ceil(totalItems / 6);
  const movies = await Movie.find(filter)
    .sort({ status: 1, priority: -1, runtime: 1, createdAt: -1 })
    .skip((page - 1) * 6).limit(6);
  return sendSuccess(res, 200, 'Movies loaded', { movies, page, pageSize: 6, totalItems, totalPages });
}));

router.get('/:id', asyncRoute(async (req, res) => {
  if (!safeId(req.params.id)) return sendError(res, 400, 'Invalid movie ID');
  const movie = await Movie.findById(req.params.id);
  if (!movie) return sendError(res, 404, 'Movie not found');
  return sendSuccess(res, 200, 'Movie loaded', movie);
}));

router.post('/', asyncRoute(async (req, res) => {
  const errors = validateMovieInput(req.body, { creating: true });
  if (errors.length) return sendError(res, 400, errors.join('. '));
  // The code sequence is allocated atomically per release year by MongoDB.
  const year = Number(req.body.releaseYear);
  const counter = await Counter.findOneAndUpdate(
    { _id: year }, { $inc: { sequence: 1 } }, { new: true, upsert: true, setDefaultsOnInsert: true }
  );
  const movieCode = `MV-${year}-${String(counter.sequence).padStart(3, '0')}`;
  try {
    const movie = await Movie.create({
      ...editableFields(req.body), releaseYear: year, movieCode,
      status: 'To Watch', rating: null, watchedDate: null
    });
    return sendSuccess(res, 201, 'Movie added successfully', movie);
  } catch (error) {
    if (error.code === 11000) return sendError(res, 409, 'A movie with this title and release year already exists');
    if (error.name === 'ValidationError') return sendError(res, 400, Object.values(error.errors).map(e => e.message).join(', '));
    throw error;
  }
}));

router.put('/:id', asyncRoute(async (req, res) => {
  if (!safeId(req.params.id)) return sendError(res, 400, 'Invalid movie ID');
  if ('movieCode' in req.body || 'releaseYear' in req.body || 'status' in req.body || 'rating' in req.body || 'watchedDate' in req.body) {
    return sendError(res, 400, 'Movie Code, Release Year, status, rating and watched date cannot be changed through the edit endpoint');
  }
  const errors = validateMovieInput(req.body);
  if (errors.length) return sendError(res, 400, errors.join('. '));
  const movie = await Movie.findById(req.params.id);
  if (!movie) return sendError(res, 404, 'Movie not found');
  Object.assign(movie, editableFields(req.body));
  try {
    await movie.save();
    return sendSuccess(res, 200, 'Movie updated successfully', movie);
  } catch (error) {
    if (error.code === 11000) return sendError(res, 409, 'A movie with this title and release year already exists');
    throw error;
  }
}));

router.patch('/:id/status', asyncRoute(async (req, res) => {
  if (!safeId(req.params.id)) return sendError(res, 400, 'Invalid movie ID');
  const { status, rating } = req.body;
  if (!STATUSES.includes(status)) return sendError(res, 400, 'Invalid status');
  const movie = await Movie.findById(req.params.id);
  if (!movie) return sendError(res, 404, 'Movie not found');
  if (!allowedTransitions[movie.status].includes(status)) {
    return sendError(res, 400, `Invalid status transition: ${movie.status} cannot change to ${status}`);
  }
  if (status === 'Watched') {
    if (!Number.isInteger(Number(rating)) || Number(rating) < 1 || Number(rating) > 10) return sendError(res, 400, 'A rating from 1 to 10 is required when marking a movie Watched');
    movie.rating = Number(rating);
    movie.watchedDate = new Date();
  } else {
    if (rating !== undefined && rating !== null && rating !== '') return sendError(res, 400, 'Rating is only allowed for Watched movies');
    movie.rating = null;
    movie.watchedDate = null;
  }
  movie.status = status;
  await movie.save();
  return sendSuccess(res, 200, 'Movie status updated', movie);
}));

router.patch('/:id/rating', asyncRoute(async (req, res) => {
  if (!safeId(req.params.id)) return sendError(res, 400, 'Invalid movie ID');
  const rating = Number(req.body.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 10) return sendError(res, 400, 'Rating must be an integer from 1 to 10');
  const movie = await Movie.findById(req.params.id);
  if (!movie) return sendError(res, 404, 'Movie not found');
  if (movie.status !== 'Watched') return sendError(res, 400, 'Only Watched movies can have a rating');
  movie.rating = rating;
  await movie.save();
  return sendSuccess(res, 200, 'Rating updated', movie);
}));

router.delete('/:id', asyncRoute(async (req, res) => {
  if (!safeId(req.params.id)) return sendError(res, 400, 'Invalid movie ID');
  const movie = await Movie.findById(req.params.id);
  if (!movie) return sendError(res, 404, 'Movie not found');
  if (movie.status === 'Watching') return sendError(res, 400, 'Movies in Watching status cannot be deleted');
  await movie.deleteOne();
  return sendSuccess(res, 200, 'Movie deleted successfully', movie);
}));

export default router;
